import os
os.system('cls' if os.name == 'nt' else 'clear')  
print("[\x1b[38;5;1m1\033[0m] Arceus Animation (Recommended If Using Computer(Can Use In Termux)")
print("[\x1b[38;5;1m2\033[0m] Arceus Normal (Use For Weak Device)")
print("[\x1b[38;5;1m3\033[0m] Setup Tools")
select = input("Enter Version : ")
if select == "1":
   os.system('cls' if os.name == 'nt' else 'clear')  
   os.system("python arceus.py")
elif select == "2":
   os.system('cls' if os.name == 'nt' else 'clear')  
   os.system("python arceusnormal.py")
elif select == "3":
   os.system('cls' if os.name == 'nt' else 'clear')  
   os.system("python setup.py")
import os
print("@tretraunetwork Setup Tool Fo Arceus")
os.system(f"npm install socks --no-bin-links --unsafe-perm")
os.system(f"npm install hpack --no-bin-links --unsafe-perm")
os.system(f"npm install colors --no-bin-links --unsafe-perm")
os.system(f"npm i set-cookie-parser --no-bin-links --unsafe-perm")
os.system(f'LDFLAGS="-L/data/data/com.termux/files/usr/lib" CFLAGS="-I/data/data/com.termux/files/usr/include" pip install --no-cache-dir --force-reinstall pillow')
os.system(f"pip install asciimatics")
os.system(f"pip install rich")